<?php

declare(strict_types=1);

return App\Composition::request('php://input');
